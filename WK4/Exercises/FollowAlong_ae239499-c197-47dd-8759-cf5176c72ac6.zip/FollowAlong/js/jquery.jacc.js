/*
	jAcc: Accordion
	Compatibility: jQuery 1.8.1+
	Author: Your Name
*/

(function($){

	

})(jQuery);