/*
	jSlide Plugin
	Version: 1.1
	Framework: jQuery 1.7+
	====================================
*/

(function($){

	

})(jQuery);  //end wrapper



